-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2022-04-28 16:04:09
-- 服务器版本： 5.6.50-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dh_020a_cn`
--

-- --------------------------------------------------------

--
-- 表的结构 `nav_admin`
--

CREATE TABLE IF NOT EXISTS `nav_admin` (
  `id` int(111) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `nav_admin`
--

INSERT INTO `nav_admin` (`id`, `name`, `pass`) VALUES
(1, 'admin', 'b3360cc45c2819fc1ea9b0f16c15fdee');

-- --------------------------------------------------------

--
-- 表的结构 `nav_adver`
--

CREATE TABLE IF NOT EXISTS `nav_adver` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `picname` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `nav_adver`
--

INSERT INTO `nav_adver` (`id`, `title`, `picname`, `link`, `sort`, `type`) VALUES
(55, '刀客源码网', 'http://dh.020a.cn/Public/uploads/626a48028d5fe.png', 'https://www.dkewl.com', 1, 2),
(56, '测试', 'http://dh.020a.cn/Public/uploads/626a482826097.jpg', 'https://www.dkewl.com', 2, 1);

-- --------------------------------------------------------

--
-- 表的结构 `nav_app`
--

CREATE TABLE IF NOT EXISTS `nav_app` (
  `id` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `title` varchar(222) DEFAULT NULL,
  `picname` varchar(222) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `link` varchar(222) DEFAULT NULL,
  `addtime` varchar(222) DEFAULT NULL,
  `status` int(222) DEFAULT '1',
  `count` int(11) DEFAULT '0',
  `remen` int(11) DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `nav_app`
--

INSERT INTO `nav_app` (`id`, `type`, `title`, `picname`, `content`, `link`, `addtime`, `status`, `count`, `remen`) VALUES
(1, 1, '西瓜视频', 'http://img.lenovomm.com/ali/icon/app-img-lestore/4687-2020-12-16041555-1608106555597.png', '西瓜视频', '/404.html', '1610419859', 1, 324324, 2),
(2, 1, '爱奇艺', 'http://img.lenovomm.com/ali/icon/app-img-lestore/7244-2020-02-19030406-1582095846235.png', '爱奇艺', 'http://www.badiu.com', '1610419886', 1, 63534534, 2),
(3, 1, '优酷视频', 'http://img.lenovomm.com/ali/icon/app-img-lestore/2428-2020-12-23035435-1608710075552.png', '腾讯视频', 'http://www.baidu.com', '1610419916', 1, 14265645, 2),
(4, 1, '腾讯视频', 'http://img.lenovomm.com/ali/icon/app-img-lestore/4206-2020-12-23033255-1608708775391.png', '腾讯视频', 'http://www.baidu.com', '1610419956', 1, 65475754, 2),
(5, 1, '抖音', 'http://img.lenovomm.com/ali/img/app-img-lestore/9581-2020-07-21064137-1595328097605.gif', '抖音', 'http://www.baidu.com', '1610419982', 1, 46456456, 2),
(6, 2, '快手', 'http://img.lenovomm.com/ali/icon/app-img-lestore/1979-2020-09-03095548-1599098148040.png', '快手', 'http://www.baidu.com', '1610420021', 1, 6542323, 2),
(7, 2, '没拍', 'http://img.lenovomm.com/ali/icon/app-img-lestore/6154-2020-02-13024256-1581576176341.png', '美拍应用介绍', 'http://www.baidu.com', '1610420047', 1, 65452452, 2),
(9, 2, '刀客源码网', 'https://www.dkewl.com/statics/cs_logo/logo_400x400.jpg', '', '', '1651132512', 1, 999, 2);

-- --------------------------------------------------------

--
-- 表的结构 `nav_config`
--

CREATE TABLE IF NOT EXISTS `nav_config` (
  `id` int(11) NOT NULL,
  `webname` varchar(222) DEFAULT NULL,
  `resou` varchar(222) DEFAULT NULL,
  `link` varchar(222) DEFAULT NULL,
  `webtitle` varchar(222) DEFAULT NULL,
  `webkeywords` varchar(222) DEFAULT NULL,
  `webdescription` varchar(222) DEFAULT NULL,
  `gonggao` varchar(222) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `nav_config`
--

INSERT INTO `nav_config` (`id`, `webname`, `resou`, `link`, `webtitle`, `webkeywords`, `webdescription`, `gonggao`) VALUES
(1, 'APP应用导航_刀客源码网', NULL, 'http://www.baidu.com', '测试APP应用_刀/客/源/码/演示', '测试APP应用导航刀客源码演示', '测试APP应用导航刀客源码网演示www.dkewl.com', '欢迎访问记住永久域名，测试刀客源码网APP应用导航演示');

-- --------------------------------------------------------

--
-- 表的结构 `nav_link`
--

CREATE TABLE IF NOT EXISTS `nav_link` (
  `id` int(11) NOT NULL,
  `title` varchar(222) DEFAULT NULL,
  `link` varchar(222) DEFAULT NULL,
  `addtime` varchar(222) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `nav_type`
--

CREATE TABLE IF NOT EXISTS `nav_type` (
  `id` int(11) NOT NULL,
  `title` varchar(222) DEFAULT NULL,
  `sort` varchar(222) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `nav_type`
--

INSERT INTO `nav_type` (`id`, `title`, `sort`) VALUES
(1, '社交', '1'),
(2, '直播', '2'),
(3, '游戏', '3'),
(4, '去1111', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nav_adver`
--
ALTER TABLE `nav_adver`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nav_app`
--
ALTER TABLE `nav_app`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nav_config`
--
ALTER TABLE `nav_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nav_link`
--
ALTER TABLE `nav_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nav_type`
--
ALTER TABLE `nav_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nav_adver`
--
ALTER TABLE `nav_adver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `nav_app`
--
ALTER TABLE `nav_app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `nav_config`
--
ALTER TABLE `nav_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `nav_link`
--
ALTER TABLE `nav_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `nav_type`
--
ALTER TABLE `nav_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
